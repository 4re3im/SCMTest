-- Execute drop column
ALTER TABLE `tngdb`.`CupGoTabs`
DROP COLUMN `HMProduct`;