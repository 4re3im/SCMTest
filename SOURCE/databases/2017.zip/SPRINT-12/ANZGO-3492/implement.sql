-- Execute add column script
ALTER TABLE `tngdb`.`CupGoTabs`
ADD COLUMN `HMProduct` VARCHAR(45) NOT NULL DEFAULT 'N' AFTER `ElevateProduct`;
-- Execute Update Script
UPDATE CupGoTabs SET HMProduct = 'Y' WHERE LOWER(TabName) IN ("interactive online resource - teacher edition", "online resource", "online teacher edition", "preview a sample");