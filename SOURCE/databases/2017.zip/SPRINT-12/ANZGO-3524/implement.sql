-- Create temp table Hotmaths_APITemp and insert Hotmaths_API
-- this table will now be used as basis for rollback
CREATE TABLE Hotmaths_APITemp AS SELECT * FROM Hotmaths_API;

-- Run update script
UPDATE Hotmaths_API SET access_token = '41aa785b-7ce2-4b7c-831e-10e73330f3d1' WHERE env = 'testing';
-- If no rollback is to be done, delete Hotmaths_APITemp