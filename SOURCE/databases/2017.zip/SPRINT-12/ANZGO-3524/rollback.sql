-- Rollback script
-- only run when implement has run
DROP TABLE Hotmaths_API;
RENAME TABLE Hotmaths_APITemp TO Hotmaths_API;