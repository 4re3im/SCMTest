-- ROLLBACK
-- step1 Drop existing tables
DROP TABLE CupGoUserSubscriptionHMProvision;
