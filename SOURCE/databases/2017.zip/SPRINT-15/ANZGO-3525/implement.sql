-- Backup ProvisioningUsers

CREATE TABLE `tngdb`.`ProvisioningHotMathsUserClassesQueue` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `provisioningUsersID` INT NOT NULL,
  `classCode` VARCHAR(60) NOT NULL,
  `fileID` INT NOT NULL,
  `created` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`provisioningUsersID`) REFERENCES ProvisioningUsers(id))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8
COMMENT = 'Table containing HotMaths classes which Users are added to upon provisioning.';

ALTER TABLE `tngdb`.`ProvisioningUsers`
CHANGE COLUMN `Remarks` `Remarks` VARCHAR(1000) NULL DEFAULT NULL;