DROP TABLE tngdb.ProvisioningHotMathsUserClassesQueue;

ALTER TABLE `tngdb`.`ProvisioningUsers`
CHANGE COLUMN `Remarks` `Remarks` VARCHAR(45) NULL DEFAULT NULL;