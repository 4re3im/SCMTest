-- Rollback script
-- only run when implement has run then failed
UPDATE CupGoUserSubscription AS cgus
INNER JOIN CupGoUserSubscriptionTemp cgust ON (cgust.ID = cgus.ID)
SET cgus.EndDate = cgust.EndDate, cgus.DaysRemaining = cgust.DaysRemaining;