-- Create temp table CupGoUserSubscriptionTemp and insert CupGoUserSubscription IDs with old EndDate
-- this table will now be used as basis for rollback
CREATE TABLE CupGoUserSubscriptionTemp AS SELECT * FROM CupGoUserSubscription WHERE (YEAR(EndDate) = '1970' OR YEAR(EndDate) = '1971' OR YEAR(EndDate) = '1972' OR YEAR(EndDate) = '1974') AND (Duration > 0);

-- Run update for EndDate
UPDATE CupGoUserSubscription SET EndDate = DATE_ADD(CreationDate, INTERVAL Duration  DAY)
                        WHERE (YEAR(EndDate) = '1970' OR YEAR(EndDate) = '1971' OR YEAR(EndDate) = '1972' OR YEAR(EndDate) = '1974')
                        AND (Duration > 0);

-- Run update for DaysRemaining
UPDATE CupGoUserSubscription AS cgus INNER JOIN CupGoUserSubscriptionTemp cgust ON (cgust.ID = cgus.ID) SET cgus.DaysRemaining = DATEDIFF(cgus.EndDate, Now());
-- If no rollback is to be done, delete CupGoUserSubscriptionTemp