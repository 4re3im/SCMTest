-- Rollback script
UPDATE CupGoAccessCodes AS cgac
INNER JOIN CupGoAccessCodesTemp cgact ON (cgact.ID = cgac.ID)
SET cgac.UserID = cgact.UserID, cgac.DateActivated = cgact.DateActivated, cgac.IPAddress = cgact.IPAddress, cgac.UserAgent = cgact.UserAgent, cgac.Usable = cgact.Usable;