-- Create temp table and insert
-- this table will now be used as basis for rollback
CREATE TABLE CupGoAccessCodesTemp AS SELECT * FROM CupGoAccessCodes WHERE DateActivated > '2016-07-31 23:59:59' AND DateActivated < '2017-08-01 00:00:00' AND UsageCount < UsageMax AND Usable = 'N';

-- Run update script
UPDATE CupGoAccessCodes SET UserID = NULL, DateActivated = NULL, IPAddress = NULL, UserAgent = NULL, Usable = 'Y' WHERE DateActivated > '2016-07-31 23:59:59' AND DateActivated < '2017-08-01 00:00:00' AND UsageCount < UsageMax AND Usable = 'N';

-- If no rollback is to be done, delete CupGoAccessCodesTemp