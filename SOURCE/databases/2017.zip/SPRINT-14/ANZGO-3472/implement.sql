-- Backup tngdb.CupGoLogUser
-- Then execute the script

ALTER TABLE `tngdb`.`CupGoLogUser`
ADD INDEX `FK_Log_User_UserIDCreated` (`UserID` ASC, `CreatedDate` ASC);

ALTER TABLE `tngdb`.`CupGoLogUser`
ADD INDEX `FK_Log_User_Created` (`CreatedDate` ASC);