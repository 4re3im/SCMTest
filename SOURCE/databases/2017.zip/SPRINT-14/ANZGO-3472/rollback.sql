ALTER TABLE `tngdb`.`CupGoLogUser`
DROP INDEX `FK_Log_User_Created` ;

ALTER TABLE `tngdb`.`CupGoLogUser`
DROP INDEX `FK_Log_User_UserIDCreated` ;


