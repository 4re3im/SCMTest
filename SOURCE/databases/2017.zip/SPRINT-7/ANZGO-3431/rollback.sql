-- ROLLBACK
-- step1 Drop existing tables
DROP TABLE tngdb.CupGoLogUser;
-- step2 Import back up of affected table
