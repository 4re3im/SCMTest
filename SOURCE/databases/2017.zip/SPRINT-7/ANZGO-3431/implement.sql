-- Note: Backup tngdb.CupGoLogUser first.

-- Insert all data from CambridgeGO_Live.Log_User to tngdb.CupGoLogUser
INSERT INTO tngdb.CupGoLogUser
SELECT * FROM CambridgeGO_Live.Log_User;

-- Create tmp table
CREATE TABLE `CupGoLogUserTmp` (
   `UserID` int(11) DEFAULT NULL,
   `IPAddress` varchar(15) CHARACTER SET utf8 DEFAULT NULL,
   `QueryString` text CHARACTER SET utf8,
   `Action` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
   `CreatedDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
   `PageName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
   `UserAgent` text CHARACTER SET utf8,
   `Version` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
   `ScriptName` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
   `Info` text CHARACTER SET utf8,
   `SessionID` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
   `PID` int(11) DEFAULT NULL,
   `ProductName` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
   `TabLevel` tinyint(3) unsigned DEFAULT NULL,
   `TabID` int(11) DEFAULT NULL,
   `AccessLevel` tinyint(3) unsigned DEFAULT NULL,
   `TabName` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
   KEY `FK_Log_User_Search` (`Action`,`PageName`,`ScriptName`,`PID`,`TabID`,`CreatedDate`),
   KEY `FK_Log_User_UserID` (`UserID`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

 -- Verify that the table is created
 SHOW CREATE TABLE CupGoLogUserTmp;

-- Copy all data from tngdb.CupGoLogUser without duplicates

INSERT INTO tngdb.CupGoLogUserTmp
SELECT DISTINCT UserID, IPAddress, QueryString, Action, CreatedDate, PageName, UserAgent, Version, ScriptName, Info, SessionID, PID, ProductName, TabLevel, TabID, AccessLevel, TabName
FROM tngdb.CupGoLogUser;

-- Drop original table

DROP TABLE tngdb.CupGoLogUser;

-- Rename tngdb.CupGoLogUserTmp to tngdb.CupGoLogUser

RENAME TABLE tngdb.CupGoLogUserTmp TO tngdb.CupGoLogUser;

-- Verify Content

SELECT COUNT(*) FROM CupGoLogUser;
