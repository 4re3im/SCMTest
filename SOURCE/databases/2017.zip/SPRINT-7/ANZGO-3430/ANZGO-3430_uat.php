<?php

/*
* ANZGO-3430 GA - GO Users
* DATABASE FIX for updating registration dates of users
*/

$servername = "anz-uat-rds.aws.cambridge.edu.au";
$username = "anzrds";
$password = "7saN8jgetm";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}

$query1 =   "SELECT CambridgeGO_Live.User.ID, CambridgeGO_Live.User.CreationDate, tngdb.UserGroups.ugEntered
            FROM CambridgeGO_Live.User
            LEFT OUTER JOIN tngdb.UserGroups
            ON tngdb.UserGroups.uID=CambridgeGO_Live.User.ID
            WHERE tngdb.UserGroups.ugEntered IS NOT NULL
            AND CambridgeGO_Live.User.CreationDate<>tngdb.UserGroups.ugEntered;";
$counter = 0;

$result1 = $conn->query($query1);

if ($result1->num_rows > 0) {
          // output data of each row
          while($row1 = $result1->fetch_assoc()) {
                  $oldID = $row1['ID'];
                  $correctDate = $row1['CreationDate'];
                  $wrongDate = $row1['ugEntered'];
                  echo $oldID . " | " . $correctDate . " | " . $wrongDate . "\n";

                  $query2 = "UPDATE tngdb.UserGroups
                             SET ugEntered='$correctDate'
                             WHERE uID=$oldID;";
                  $conn->query($query2);

                  $counter += mysqli_affected_rows($conn);
          }
}

echo "Total updated users:" . $counter . "\n";

$conn->close();
?>
