-- step 1: back up table CupGoAccessCodes
-- step 2: run commands below
UPDATE CupGoAccessCodes SET UsageCount = 1 WHERE AccessCode="QE4Y-2V58-U69P-EJDR";
UPDATE CupGoAccessCodes SET UsageCount = 1 WHERE AccessCode="4LJ7-ZNVB-ZYJX-TGRX";
