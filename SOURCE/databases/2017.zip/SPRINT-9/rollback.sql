ALTER TABLE `tngdb`.`CupGoTabs`
DROP COLUMN `ElevateProduct`;
DROP TABLE tngdb.ElevateValidationHashes;
