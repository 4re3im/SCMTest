ALTER TABLE `tngdb`.`CupGoTabs`
ADD COLUMN `ElevateProduct` VARCHAR(1) NULL DEFAULT 'N' AFTER `MyResourcesLink`;

CREATE TABLE tngdb.ElevateValidationHashes (
    id int(11) AUTO_INCREMENT,
    uID int(11) NOT NULL,
    token varchar(20) NOT NULL,
    dateCreated timestamp,
    PRIMARY KEY (id)
);
