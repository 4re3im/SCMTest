-- ANZGO-3576
-- Please replace <USER_IDs> with the content of teacher_list.txt attached in change request.

use tngdb;
-- Creates a backup table for affected User Subscription
CREATE TABLE CupGoUserSubscriptionRollover as (
SELECT cgus.* FROM CupGoUserSubscription cgus
INNER JOIN CupGoSubscriptionAvailability cgsa ON cgus.SA_ID = cgsa.ID
WHERE cgus.UserID IN (SELECT u.uID FROM Users u INNER JOIN UserGroups ug ON u.uID = ug.uID WHERE ug.gID = 5)
AND cgus.ID IN (
        SELECT MAX(ID) FROM CupGoUserSubscription
        WHERE UserID = cgus.UserID AND S_ID = cgus.S_ID
    )
AND cgsa.HmID IS NOT NULL
AND cgsa.Demo = 'N'
AND cgus.Active = 'N'
AND cgus.UserID IN (<USER_IDs>)
GROUP BY cgus.UserID, cgus.S_ID
ORDER BY cgus.ID DESC
);

-- Creates a backup table for affected TabAccess
CREATE TABLE CupGoTabAccessRollover as (
SELECT * FROM CupGoTabAccess WHERE US_ID IN (SELECT ID FROM CupGoUserSubscriptionRollover)
);

-- Extends UserSubscription to 2018
UPDATE CupGoUserSubscription cgus
INNER JOIN CupGoUserSubscriptionRollover roll ON cgus.ID = roll.ID
SET cgus.Active = 'Y', cgus.EndDate = '2018-12-31 23:59:57',
    cgus.DaysRemaining = DATEDIFF('2018-12-31 23:59:59', NOW()), cgus.DateDeactivated = NULL;


-- Extends TabAccess to 2018
UPDATE CupGoTabAccess cgta
INNER JOIN CupGoTabAccessRollover roll ON cgta.ID = roll.ID
SET cgta.Active = 'Y', cgta.EndDate = '2018-12-31 23:59:57',
    cgta.DaysRemaining = DATEDIFF('2018-12-31 23:59:59', NOW()), cgta.DateDeactivated = NULL;