-- Reverts UserSubscription to original value from backup table

UPDATE CupGoUserSubscription cgus
INNER JOIN CupGoUserSubscriptionRollover roll ON cgus.ID = roll.ID
SET cgus.Active = roll.Active, cgus.EndDate = roll.EndDate,
	cgus.DaysRemaining = roll.DaysRemaining, cgus.DateDeactivated = roll.DateDeactivated;

-- Reverts TabAccess to original value from backup table

UPDATE CupGoTabAccess cgta
INNER JOIN CupGoTabAccessRollover roll ON cgta.ID = roll.ID
SET cgta.Active = roll.Active, cgta.EndDate = roll.EndDate,
    cgta.DaysRemaining = roll.DaysRemaining, cgta.DateDeactivated = roll.DateDeactivated;