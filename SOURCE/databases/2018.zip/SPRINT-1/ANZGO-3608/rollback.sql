# rollback.sql
# run this incase of rollback
ALTER TABLE UserValidationHashes MODIFY uHash varchar(64);