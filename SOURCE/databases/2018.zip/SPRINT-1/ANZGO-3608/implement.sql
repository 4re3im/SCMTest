# implement.sql
# run to change uHash varchar 64 to 128
ALTER TABLE UserValidationHashes MODIFY uHash varchar(128);