-- 1. This will create a copy of the Users table and insert all data in backup table
CREATE TABLE Users_Backup LIKE Users; 
INSERT Users_Backup SELECT * FROM Users;

-- 2. This will create a temp table that will be the basis for the IDs to be deleted
CREATE TABLE UsersForDeletionStudents
AS 
    SELECT u.uID AS UserID
    FROM Users u
    JOIN UserGroups ug ON u.uID=ug.uID
    WHERE ug.gID = 4
    AND u.uDateAdded < '2015-06-15'
    AND u.uID NOT IN (
        SELECT UserID
        FROM CupGoLogUser cglu
        WHERE cglu.CreatedDate > '2015-06-15'
        AND UserID IS NOT NULL
        GROUP BY cglu.UserID
        ORDER BY cglu.CreatedDate DESC
    ) 
    AND u.uID NOT IN (
        SELECT UserID
        FROM CupGoUserSubscription
        WHERE Active='Y'
        AND UserID IS NOT NULL
    )
    ORDER BY u.uDateAdded DESC;

ALTER TABLE UsersForDeletionStudents ADD INDEX (UserID);

CREATE TABLE UsersForDeletionTeachers
AS 
    SELECT u.uID AS UserID
    FROM Users u
    JOIN UserGroups ug ON u.uID=ug.uID
    WHERE ug.gID = 5
    AND u.uDateAdded < '2015-06-15'
    AND u.uID NOT IN (
        SELECT UserID
        FROM CupGoLogUser cglu
        WHERE cglu.CreatedDate > '2015-06-15'
        AND UserID IS NOT NULL
        GROUP BY cglu.UserID
        ORDER BY cglu.CreatedDate DESC
    ) 
    AND u.uID NOT IN (
        SELECT UserID
        FROM CupGoUserSubscription
        WHERE Active='Y'
        AND UserID IS NOT NULL
    )
    ORDER BY u.uDateAdded DESC;

ALTER TABLE UsersForDeletionTeachers ADD INDEX (UserID);

-- 3. Run the delete query from the ID created in the temp table
DELETE 
FROM Users
WHERE uID IN (SELECT * FROM UsersForDeletionStudents);

DELETE 
FROM Users
WHERE uID IN (SELECT * FROM UsersForDeletionTeachers);
