-- 1. drop the table Users as this will now have errors
DROP TABLE Users;

-- 2. rename the backup users to users
RENAME TABLE Users_Backup TO Users;

-- 3. drop the temp tables
DROP TABLE UsersForDeletionStudents;
DROP TABLE UsersForDeletionTeachers;
