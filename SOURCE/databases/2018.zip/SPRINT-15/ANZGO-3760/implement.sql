-- CREATE TABLE CupGoAccessCodeReactivations
CREATE TABLE CupGoAccessCodeReactivations (
ID bigint(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
AccessCodeParentID VARCHAR(20) NOT NULL,
AccessCodeChildID VARCHAR(20) NOT NULL,
CreationDate TIMESTAMP
) ENGINE=INNODB;