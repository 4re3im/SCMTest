-- Rollback script
UPDATE hub.permissions AS p
INNER JOIN hub.permissions_bk AS bk ON (bk.ID = p.ID)
SET p.released_at = bk.released_at, p.updated_at = bk.updated_at;