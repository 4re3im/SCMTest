-- Create temp table and insert
-- this table will now be used as basis for rollback
CREATE TABLE hub.permissions_bk AS SELECT p.*, (SELECT COUNT(*) FROM hub.activations WHERE permission_id = p.id) activations FROM hub.permissions p
INNER JOIN hub.activations a ON p.id = a.permission_id
WHERE a.activated_at > '2017-07-31 23:59:59'
AND a.activated_at < '2018-08-01 00:00:00'
AND p.proof IS NOT NULL
AND p.released_at IS NULL
GROUP BY p.id
HAVING activations < p.limit;

-- Run update script
UPDATE hub.permissions SET released_at = NOW() WHERE id IN (SELECT id FROM (SELECT p.id, p.proof, p.limit, (SELECT COUNT(*) FROM hub.activations WHERE permission_id = p.id) activations FROM hub.permissions p
INNER JOIN hub.activations a ON p.id = a.permission_id
WHERE a.activated_at > '2017-07-31 23:59:59'
AND a.activated_at < '2018-08-01 00:00:00'
AND p.proof IS NOT NULL
AND p.released_at IS NULL
GROUP BY p.id
HAVING activations < p.limit) as p1);