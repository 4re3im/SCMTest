ALTER TABLE `tngdb`.`CupGoUserSubscription`
ADD COLUMN `CreatedBy` INT NULL DEFAULT NULL AFTER `ArchiveDate`;
