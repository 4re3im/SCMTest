ALTER TABLE `tngdb`.`CupGoUserSubscription`
DROP COLUMN `CreatedBy`;
