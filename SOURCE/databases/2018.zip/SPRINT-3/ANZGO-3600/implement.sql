-- Create temp table CupGoTabAccessTemp and insert CupGoTabAccess
-- this table will now be used as basis for rollback
CREATE TABLE CupGoTabAccessTemp AS SELECT * FROM CupGoTabAccess;

-- Create table CupGoTabAccessUpdates
CREATE TABLE `CupGoTabAccessUpdates` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `S_ID` int(11) DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Create table CupGoTabAccessUpdated
CREATE TABLE `CupGoTabAccessUpdated` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `User_ID` int(11) DEFAULT NULL,
  `S_ID` int(11) DEFAULT NULL,
  `CGTAU_ID` int(11) DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
