-- Drop table of newly added table
DROP TABLE CupGoTabAccessUpdates;
DROP TABLE CupGoTabAccessUpdated;

-- Drop table CupGoTabAccess and rename Temp table to CupGoTabAccess
DROP TABLE CupGoTabAccess;
RENAME TABLE CupGoTabAccessTemp TO CupGoTabAccess;