<?php
/*
 * ANZGO-3921 created by machua 20181114
 * Update subscriptions to 2019-12-31 12:00:00
 */
const NEW_END_DATE = '2019-12-31 12:00:00';
const ERROR_FILE = 'update_activation_error_log.txt';
const SUCCESS_FILE = 'update_activation_success_log.txt';
const DEFAULT_TNG_DB = 'tngdb';
const DEFAULT_TNG_USERNAME = 'anzrds';
const DEFAULT_TNG_PASSWORD = '7saN8jgetm';
const DEFAULT_PEAS_DB = 'hub';

function setConfig()
{
    if (isset($_SERVER["HOSTNAME"])) {
        $hostname = $_SERVER["HOSTNAME"];
        switch ($hostname) {
            case 'ip-10-111-33-73':
                define('DB_SERVER', 'anz-go-dev-db.aws.cambridge.org');
                define('DB_USERNAME', DEFAULT_TNG_USERNAME);
                define('DB_PASSWORD', DEFAULT_TNG_PASSWORD);
                define('DB_DATABASE', 'tngdb_prod');
                define('PEAS_DB_DATABASE', DEFAULT_PEAS_DB);
                define('SOURCE_FILE_CSV', 'rollover_accounts_email_dev.csv');
                break;
            case 'ip-10-111-59-187':
                define('DB_SERVER', 'anz-uat-rds.aws.cambridge.edu.au');
                define('DB_USERNAME', DEFAULT_TNG_USERNAME);
                define('DB_PASSWORD', DEFAULT_TNG_PASSWORD);
                define('DB_DATABASE', DEFAULT_TNG_DB);
                define('PEAS_DB_DATABASE', 'hub_uat');
                define('SOURCE_FILE_CSV', 'rollover_accounts_email_uat.csv');
                break;
            case 'ip-10-111-33-7':
                define('DB_SERVER', 'anz-go-testdb-rds.aws.cambridge.edu.au');
                define('DB_USERNAME', DEFAULT_TNG_USERNAME);
                define('DB_PASSWORD', DEFAULT_TNG_PASSWORD);
                define('DB_DATABASE', DEFAULT_TNG_DB);
                define('PEAS_DB_DATABASE', DEFAULT_PEAS_DB);
                define('SOURCE_FILE_CSV', 'rollover_accounts_email_staging.csv');
                break;
            case 'ip-10-111-60-73':
                define('DB_SERVER', 'anz-go-production-rds.aws.cambridge.edu.au');
                define('DB_USERNAME', DEFAULT_TNG_USERNAME);
                define('DB_PASSWORD', DEFAULT_TNG_PASSWORD);
                define('DB_DATABASE', DEFAULT_TNG_DB);
                define('PEAS_DB_DATABASE', DEFAULT_PEAS_DB);
                define('SOURCE_FILE_CSV', 'rollover_accounts_email.csv');
                break;
            default:
                echo "Error Hostname : Not set.";
        }
    } else {
        define('DB_SERVER', '127.0.0.1');
        define('DB_USERNAME', 'root');
        define('DB_PASSWORD', '');
        define('DB_DATABASE', DEFAULT_TNG_DB);
        define('PEAS_DB_DATABASE', DEFAULT_PEAS_DB);
        define('SOURCE_FILE_CSV', 'rollover_accounts_email_local.csv');

    }

}

function getUserIDsFromFile()
{
    $mysql = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    $uIDArray = array();

    if ($mysql->connect_error) {
        $message = 'Failed to connect to TNG database.';
        addMessageToFile(ERROR_FILE, $message);
        die;
    } else {
        addMessageToFile(SUCCESS_FILE, 'Successfully connected to database.');
        $file = fopen(SOURCE_FILE_CSV, 'r');
        $emailArray = array();
        while (!feof($file)) {
            $row = fgetcsv($file);
            $emailArray[] = $row[0];
        }

        fclose($file);

        array_pop($emailArray);
        $emailStr = implode('","', $emailArray);

        $sql = 'SELECT uID, uEmail FROM Users WHERE uEmail in ("' . $emailStr . '")';
        $result = $mysql->query($sql);

        while ($dbRow = $result->fetch_assoc()) {
            $uIDArray[] = $dbRow['uID'];
        }

        $result->free();
    }
    return $uIDArray;
}

function addMessageToFile($fileName, $message)
{
    $file = fopen($fileName, 'a+');
    $logStr = date('Y-m-d h:i:sa') . ' - ';
    $logStr .= $message;
    $logStr .= "\r\n";
    fwrite($file, $logStr);
    fclose($file);
}

function generateSQLFile($query)
{
    $file = fopen('implement.sql', 'w+');
    fwrite($file, $query);
    fclose($file);
}

function getUpdateActivationQuery($uIDArray)
{
    $uIDCount = count($uIDArray);
    if ($uIDCount > 0) {
        $uIDStr = implode('","', $uIDArray);
        $sql = 'UPDATE ' . PEAS_DB_DATABASE . '.activations SET ended_at = "' . NEW_END_DATE . '"';
        $sql .= ' WHERE user_id IN ("' . $uIDStr . '")';
        $sql .= ' AND  metadata LIKE \'%"DateDeactivated": null%\'';
        $sql .= ' AND ended_at < "' . NEW_END_DATE . '";';
        return $sql;
    } else {
        addMessageToFile(SUCCESS_FILE, 'No user found.');
        return '';
    }

}

// Define constant variables
setConfig();

// Get the necessary data (username, userID and brand) from csv file and TNG DB
$uIDArray = getUserIDsFromFile();

// Update dates of the activations
$sqlQuery = getUpdateActivationQuery($uIDArray);
generateSQLFile($sqlQuery);
