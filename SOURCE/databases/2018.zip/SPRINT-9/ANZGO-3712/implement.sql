-- Backup tngdb.CupGoTabAccess
-- Run
UPDATE CupGoTabAccess
SET Active = 'Y', DateDeactivated=NULL
WHERE DaysRemaining > 0 AND DateDeactivated IS NOT NULL;