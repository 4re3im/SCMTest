--- STAGING: GO
--- STEP 1: Create Back-UP tngdb.CupGoUserSubscription
-- STEP 2: RUN
UPDATE tngdb.CupGoUserSubscription
SET EndDate = '2014-12-31 14:03:49'
WHERE ID = 436409
AND UserID = 565381
AND EndDate = '0000-00-00 00:00:00';

UPDATE tngdb.CupGoUserSubscription
SET EndDate = '1971-01-01 12:00:00'
WHERE ID IN (509200, 509206, 523154, 528386, 543461, 583152, 591980)
AND UserID IN (396678, 629170, 631059, 640001, 670284, 722073)
AND EndDate = '0000-00-00 00:00:00';

--- STEP 3: Create Back-UP hub.activations
-- STEP 4: RUN
UPDATE hub.activations
SET ended_at = '2014-12-31 14:03:49'
WHERE id = 436409
AND user_id = 565381
AND ended_at = '0000-00-00 00:00:00';

UPDATE hub.activations
SET ended_at = '1971-01-01 12:00:00'
WHERE id IN (509200, 509206, 523154, 528386, 543461, 583152, 591980)
AND user_id IN (396678, 629170, 631059, 640001, 670284, 722073)
AND ended_at = '0000-00-00 00:00:00';