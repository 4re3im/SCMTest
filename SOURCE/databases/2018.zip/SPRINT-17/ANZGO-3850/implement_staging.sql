--- STAGING: GO
--- STEP 1: Create Back-UP tngdb.CupGoUserSubscription
-- STEP 2: RUN
UPDATE tngdb.CupGoUserSubscription
SET EndDate = '2014-12-31 14:03:49'
WHERE ID = 436409
AND UserID = 565381
AND EndDate = '0000-00-00 00:00:00';

UPDATE tngdb.CupGoUserSubscription
SET EndDate = '1971-01-01 12:00:00'
WHERE ID IN (509200, 509206, 528386, 536933)
AND UserID IN (396678, 631059, 622249)
AND EndDate = '0000-00-00 00:00:00';

UPDATE tngdb.CupGoUserSubscription
SET EndDate = '2018-10-15 19:41:39'
WHERE ID = 523154
AND UserID = 629170
AND EndDate = '0000-00-00 00:00:00';

--- STAGING: PEAS
--- STEP 1: Create Back-UP hub.activations
-- STEP 2: RUN
UPDATE hub.activations
SET ended_at = '2014-12-31 14:03:49'
WHERE id = 436409
AND user_id = 565381
AND ended_at = '0000-00-00 00:00:00';

UPDATE hub.activations
SET ended_at = '1971-01-01 12:00:00'
WHERE id IN (509200, 509206, 528386, 536933)
AND user_id IN (396678, 631059, 622249)
AND ended_at = '0000-00-00 00:00:00';