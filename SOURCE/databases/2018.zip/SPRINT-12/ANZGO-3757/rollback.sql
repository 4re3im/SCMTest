-- Rollback DROP TABLE CupGoAccessCodeReactivations

DROP TABLE IF EXISTS CupGoAccessCodeReactivations;