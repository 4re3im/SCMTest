-- CREATE TABLE CupGoAccessCodeReactivations
CREATE TABLE CupGoAccessCodeReactivations (
ID bigint(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
AccessCodeParentID BIGINT(20) NOT NULL,
AccessCodeChildID BIGINT(20) NOT NULL,
CreationDate TIMESTAMP,
INDEX (ID, AccessCodeParentID, AccessCodeChildID),
CONSTRAINT FOREIGN KEY (AccessCodeParentID) REFERENCES CupGoAccessCodes (ID),
CONSTRAINT FOREIGN KEY (AccessCodeChildID) REFERENCES CupGoAccessCodes (ID)
) ENGINE=INNODB;