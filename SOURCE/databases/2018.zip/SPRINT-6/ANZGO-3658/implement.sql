--Backup tngdb.CupGoAccessCodes THEN
-- Create temp table CupGoAccessCodesTemp and insert CupGoAccessCodes
-- this table and backup will now be used as basis for rollback
CREATE TABLE tngdb.CupGoAccessCodesTemp AS SELECT * FROM tngdb.CupGoAccessCodes;

-- RUN
UPDATE CupGoAccessCodes
SET UsageMax = 4
WHERE AccessCode = 'BJVB-K939-EUEA-TYLG' AND ID = 2344944;