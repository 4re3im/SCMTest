-- Rollback
-- Import the backup CupGoAccessCodes done in implement.sql
-- OR run
UPDATE CupGoAccessCodes
SET UsageMax = 3
WHERE AccessCode = 'BJVB-K939-EUEA-TYLG' AND ID = 2344944;