--- Create Backup table for tngdb.CupGoAccessCodeReactivations

--- Modify CupGoAccessCodeReactivations
ALTER TABLE tngdb.CupGoAccessCodeReactivations DROP FOREIGN KEY CupGoAccessCodeReactivations_ibfk_1;
ALTER TABLE tngdb.CupGoAccessCodeReactivations DROP FOREIGN KEY CupGoAccessCodeReactivations_ibfk_2;
ALTER TABLE tngdb.CupGoAccessCodeReactivations DROP INDEX AccessCodeParentID;
ALTER TABLE tngdb.CupGoAccessCodeReactivations DROP INDEX AccessCodeChildID;
ALTER TABLE tngdb.CupGoAccessCodeReactivations MODIFY COLUMN AccessCodeParentID VARCHAR(20);
ALTER TABLE tngdb.CupGoAccessCodeReactivations MODIFY COLUMN AccessCodeChildID VARCHAR(20);