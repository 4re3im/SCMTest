--- STEP 1: Reload the data from the backup table to CupGoTabs
TRUNCATE TABLE tngdb.CupGoTabs;
INSERT tngdb.CupGoTabs SELECT * FROM tngdb.CupGoTabsTemp_Sprint24;