<?php
/*
* ANZGO-3944 created by mtanada 20181206
* Updating Weblink Icons
*/

$username = "anzrds";
$password = "7saN8jgetm";

if (isset($_SERVER["HOSTNAME"])) {
    $hostname = $_SERVER["HOSTNAME"];
    switch ($hostname) {
        case 'ip-10-111-33-73':
            define('SERVER_NAME', 'anz-go-dev-db.aws.cambridge.org');
            define('REPORT_FILE', 'result_dev_updateWeblink_report.csv');
            define('ERROR_FILE', 'error_dev_updateWeblink_report.csv');
            break;
        case 'ip-10-111-59-187':
            define('SERVER_NAME', 'anz-uat-rds.aws.cambridge.edu.au');
            define('REPORT_FILE', 'result_uat_updateWeblink_report.csv');
            define('ERROR_FILE', 'error_uat_updateWeblink_report.csv');
            break;
        case 'ip-10-111-33-7':
            define('SERVER_NAME', 'anz-go-testdb-rds.aws.cambridge.edu.au');
            define('REPORT_FILE', 'result_staging_updateWeblink_report.csv');
            define('ERROR_FILE', 'error_staging_updateWeblink_report.csv');
            break;
        case 'ip-10-111-60-73':
            define('SERVER_NAME', 'anz-go-production-rds.aws.cambridge.edu.au');
            define('REPORT_FILE', 'result_live_updateWeblink_report.csv');
            define('ERROR_FILE', 'error_live_updateWeblink_report.csv');
            break;
        default:
            echo "Error Hostname : Not set.";
    }
} else {
    $hostname = 'localhost';
    $username = "root";
    $password = "password";
    define('SERVER_NAME', $hostname);
    define('REPORT_FILE', 'result_local_updateWeblink_report.csv');
    define('ERROR_FILE', 'error_local_updateWeblink_report.csv');
}

/*
 * Report Logging
 * @param log information, $filename
*/
function trackLogReport($logDetails, $filename)
{
    $file = fopen($filename, 'a+');
    $logDetails .= "\r\n";
    fwrite($file, $logDetails);
    fclose($file);
}

/*
 * Fetch all Tab Ids with Weblinks as the TabName and Update the TabIcon with the new uploaded one
 * @param db connection, $newWeblinkIconId
*/
function updateWeblinkIconID($conn, $newWeblinkIconId)
{
    $tabIdArray = array();
    $updatedCount = 0;

    // Selecting Tab IDs to be updated
    $tabIdsQuery = "SELECT ID FROM tngdb.CupGoTabs WHERE TabName LIKE 'Weblink%'";
    foreach ($conn->query($tabIdsQuery) as $tabId) {
        array_push($tabIdArray, (int)$tabId['ID']);
    }
    $tabIds = rtrim(implode(",", $tabIdArray), ",");
    trackLogReport("Tab IDs to be updated: \n $tabIds \n", REPORT_FILE);

    // Updating TabID with the new TabIcon ID
    foreach ($tabIdArray as $key => $id) {
        $updateQuery = "UPDATE tngdb.CupGoTabs SET TabIcon = $newWeblinkIconId WHERE ID = $id";
        $result = $conn->query($updateQuery);
        if ($result) {
            $updatedCount++;
            trackLogReport("Tab ID: $id updated to TabIcon: $newWeblinkIconId", REPORT_FILE);
        } else {
            trackLogReport("Tab ID: $id NOT updated with TabIcon: $newWeblinkIconId", ERROR_FILE);
        }
    }
    return $updatedCount;
}

/*
 *  MAIN SCRIPT
 */

// Create connection
$conn = new mysqli(SERVER_NAME, $username, $password);

// Check connection
if ($conn->connect_error) {
    die ("Connection failed: " . $conn->connect_error);
}

if (isset($argv[1]) && is_numeric($argv[1])) {
    $count = updateWeblinkIconID($conn, (int)$argv[1]);
    trackLogReport("Updated count: $count \n", REPORT_FILE);
    echo "Done! \n";
} else {
    echo "Missing argument: php updateWeblinkIcon.php [ID] \n";
    echo "Specify new Weblink ID. Please try again. \n";
}
