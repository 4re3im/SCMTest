--- STEP 1: Create backup table for tngdb.CupGoTabs
CREATE TABLE tngdb.CupGoTabsTemp_Sprint24 LIKE tngdb.CupGoTabs;
INSERT tngdb.CupGoTabsTemp_Sprint24 SELECT * FROM tngdb.CupGoTabs;