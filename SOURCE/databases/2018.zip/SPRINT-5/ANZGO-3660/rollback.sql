-- ROLLBACK SQL

-- Drop table CupGoAccessCodeBatch and rename Temp table to CupGoAccessCodeBatch
-- Drop table CupGoAccessCodes and rename Temp table to CupGoAccessCodes
DROP TABLE CupGoAccessCodeBatch;
DROP TABLE CupGoAccessCodes;
RENAME TABLE CupGoAccessCodeBatchTemp TO CupGoAccessCodeBatch, CupGoAccessCodesTemp TO CupGoAccessCodes;

-- OR Import the backup CupGoAccessCodeBatch and CupGoAccessCodes