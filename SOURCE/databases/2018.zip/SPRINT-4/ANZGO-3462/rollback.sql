ALTER TABLE `tngdb`.`ProvisioningUsers`
    CHARACTER SET= latin1,
  CHANGE COLUMN `FirstName` `FirstName` VARCHAR(45) NULL DEFAULT NULL ,
  CHANGE COLUMN `LastName` `LastName` VARCHAR(45) NULL DEFAULT NULL ,
  CHANGE COLUMN `Email` `Email` VARCHAR(45) NULL DEFAULT NULL ,
  CHANGE COLUMN `Status` `Status` VARCHAR(45) NULL DEFAULT 'Processing' ,
  DROP COLUMN `completed`;