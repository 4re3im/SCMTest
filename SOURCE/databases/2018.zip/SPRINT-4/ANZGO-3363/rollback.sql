-- DROP edited CupGoContentDetail
-- IMPORT CupGoContentDetail backup


