-- STEP 1: Backup tngdb.CupGoContentDetail
-- STEP 2: Apply query below
UPDATE tngdb.CupGoContentDetail SET FileUploadDate='1970-01-01 10:00:00' WHERE FileUploadDate IS NULL;


