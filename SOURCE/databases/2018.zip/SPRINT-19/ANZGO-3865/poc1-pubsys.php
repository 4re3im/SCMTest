<?php

// ANZGO-3865 Created by Shane Camus 9/21/2018
// POC1 FOR PUBSYS MIGRATION

define('ORIGIN_URL', 'cambridge.edu.au');
define('HEADER_CT_JSON', 'Content-Type: application/json');

function setConfig()
{
    $hostname = $_SERVER["HOSTNAME"];

    // 1 DEV, 2 UAT, 3 STAGING, 4 PROD, 5 LOCAL
    if ($hostname === 'ip-10-111-33-73') {
        define('SECRET_KEY', 'test1234');
        define('URL', 'https://hub-dev.cambridge.org/entitlement/api/v1/');
    } elseif ($hostname === 'ip-10-111-59-187') {
        define('SECRET_KEY', 'test1234');
        define('URL', 'https://hub-uat.cambridge.org/entitlement/api/v1/');
    } elseif ($hostname === 'ip-10-111-33-7') {
        define('SECRET_KEY', '83wue1eYyGX7Bs6pG8');
        define('URL', 'https://hub-stg.cambridge.org/entitlement/api/v1/');
    } elseif ($hostname === 'ip-10-111-60-73') {
        define('SECRET_KEY', 't12RSEKYBQSQzlbV5a');
        define('URL', 'https://peas.cambridge.org/entitlement/api/v1/');
    } else {
        define('SECRET_KEY', 'test1234');
        define('URL', 'localhost:3333/entitlement/api/v1/');
    }
}

function getAllISBNs()
{
    $file = fopen('isbns.csv', 'r');

    $isbn = array();
    while(!feof($file)) {
        $row = fgetcsv($file);
        $isbn[$row[0]] = $row[1];
    }

    fclose($file);
    array_pop($isbn);

    return $isbn;
}

function curlAPI($path, $method, $header, $payload)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, URL . $path);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    if ($header !== '') {
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(HEADER_CT_JSON, $header));
    } else {
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(HEADER_CT_JSON));
    }

    if ($payload !== '') {
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload));
    }


    $output = json_decode(curl_exec($curl), true);
    curl_close($curl);

    return $output;
}

function generateCode()
{
    $params = array (
        'origin_url' => ORIGIN_URL,
        'secret_key' => SECRET_KEY
    );

    return curlAPI('auth/token/generate', 'POST', '', $params);
}

function findProductByISBN($token, $isbn)
{
    return curlAPI("products?metaFields=ISBN_13&keyword=$isbn" , 'GET', $token, '');
}

function editProductByID($token, $pID, $metadata)
{
    $params = array (
        'metadata' => json_encode($metadata)
    );

    return curlAPI("products/$pID", 'PUT', $token, $params);
}

function addProduct($token, $metadata)
{
    $params = array (
        'metadata' => json_encode($metadata)
    );

    return curlAPI('products/', 'POST', $token, $params);
}

function findEntitlementByID($token, $id)
{
    return curlAPI("entitlements/$id", 'GET', $token, '');
}

function findEntitlementsByProductID($token, $pID)
{
    return curlAPI("entitlements?product_id=$pID", 'GET', $token, '');
}

function addEntitlement($token, $pID, $eTypeID, $metadata)
{
    $params = array (
        'product_id' => $pID,
        'entitlement_type_id' => $eTypeID,
        'metadata' => json_encode($metadata)
    );

    return curlAPI('entitlements/', 'POST', $token, $params);
}

function findBatchesByEntitlementIDAndName($token, $eID)
{
    if (curlAPI("batches?entitlement_id=$eID&name=web%20direct", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=web%20direct1", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=webdirect", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=edumar", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=website", 'GET', $token, '')['total']) {
        return $eID;
    } else {
        return false;
    }
}

function addMessageToFile($fileName, $message)
{
    $file = fopen($fileName, 'a+');
    $message .= "\r\n";
    fwrite($file, $message);
}

//--------------------------------------------  MAIN CODE --------------------------------------------

// STEP 0: DEFINE CONSTANT VARIABLES
setConfig();

// STEP 1: OPEN CSV FILE AND FETCH ISBNS
$isbns = getAllISBNs();

// STEP 2: GENERATE ACCESS TOKEN (NOTE EXPIRES WITHIN 2 HOURS)
$token = "Authorization: Bearer " . generateCode()['data']['token'];

// STEP 3: PREPARE ERROR, SUCCESS REPORT, AND JSON FILES
$errorFile = 'pubsys_error_file.txt';
$successReportFile = 'pubsys_success_report_file.txt';
$entitlementIDsFile ='pubsys_new_entitlement_ids.json';

addMessageToFile($successReportFile, "New ISBN (ProductID) -> EntitlementID");

// STEP 4: PREPARE ARRAY FOR ENTITLEMENT IDS
$duplicatedEntitlementIDs = array();

// STEP 5: LOOP THROUGH EACH ISBN AND FIND PRODUCT
foreach ($isbns as $oldISBN => $newISBN) {

    $oldProduct = findProductByISBN($token, $oldISBN);

    // STEP 6: CHECK IF PRODUCT EXISTS, ELSE LOG ERROR
    if ($oldProduct['total'] !== 0) {

        $productID = $oldProduct['data'][0]['id'];
        $productMetadata = $oldProduct['data'][0]['metadata'];
        $productMetadataOld = $productMetadata;
        $productMetadataNew = $productMetadata;

        // STEP 7: CHECK IF PRODUCT NAME HAS NO `(CARD)` STRING, ELSE LOG ERROR
        if (!(strpos($productMetadataOld['CMS_Name'], ' (CARD)'))) {

            // STEP 8: APPEND 'CARD' TO PRODUCT NAME OF OLD ISBN
            $productMetadataOld['CMS_Name'] = $productMetadataOld['CMS_Name'] . ' (CARD)';

            // STEP 9: EDIT PRODUCT USING API
            $editedProduct = editProductByID($token, $productID, $productMetadataOld);

            // STEP 10: CHECK IF SUCCESSFUL EDIT, ELSE LOG
            if ($editedProduct['success']) {

                $oldProductMessage = $editedProduct['message'];
                echo "$oldISBN: $oldProductMessage \n";
                addMessageToFile($successReportFile, "$oldISBN: $oldProductMessage");

            } else {
                addMessageToFile($errorFile, "$oldISBN: Failed to update name of product with CARD");
            }

        } else {
            addMessageToFile($errorFile, "$oldISBN: Product already has (CARD) on product name");
        }

        // STEP 11: REPLACE OLD ISBN TO NEW ISBN, UPDATE CREATION DATE, AND APPEND 'CODE' TO PRODUCT NAME
        $productMetadataNew['ISBN_13'] = $newISBN;
        $productMetadataNew['CreationDate'] = date('Y-m-d h:i:s');
        if (strpos($productMetadataNew['CMS_Name'], ' (CARD)')) {
            $productMetadataNew['CMS_Name'] = str_replace(' (CARD)', ' (CODE)', $productMetadataNew['CMS_Name']);
        } else if (!strpos($productMetadataNew['CMS_Name'], ' (CODE)')) {
            $productMetadataNew['CMS_Name'] = $productMetadataNew['CMS_Name'] . ' (CODE)';
        }

        $newProduct = findProductByISBN($token, $newISBN);

        // STEP 12: CHECK IF NEW ISBN DOESN'T EXIST, ELSE LOG
        if ($newProduct['total'] === 0) {

            // STEP 13: DUPLICATE PRODUCT USING API
            $duplicatedProduct = addProduct($token, $productMetadataNew);

            // STEP 14: CHECK IF SUCCESSFUL DUPLICATE, ELSE LOG ERROR
            if ($duplicatedProduct['success']) {

                $newProductMessage = $duplicatedProduct['message'];
                echo "$newISBN: $newProductMessage \n";
                addMessageToFile($successReportFile, "$newISBN: " . $duplicatedProduct['message']);

                // STEP 15: GET PRODUCT ID OF NEW DUPLICATED PRODUCT
                $duplicatedProductID = $duplicatedProduct['data']['id'];

                // STEP 16: FIND ENTITLEMENT BY NEW PRODUCT ID
                $entitlements = findEntitlementsByProductID($token, $productID);

                // STEP 17: CHECK IF ENTITLEMENT EXIST, ELSE LOG ERROR
                if ($entitlements['total'] !== 0) {
                    $entitlementIDs = array_column($entitlements['data'], 'id');

                    $eIDMatchedCount = 0;

                    // STEP 18: LOOP THROUGH EACH ENTITLEMENT
                    foreach ($entitlementIDs as $eID) {

                        // STEP 19: CHECK FOR WEB DIRECT OR WEB DIRECT1 OR EDUMAR, ELSE LOG ERROR
                        // ELSE LOG ERROR
                        if (!findBatchesByEntitlementIDAndName($token, $eID)) {
                            continue;
                        }

                        // STEP 20: FETCH ENTITLEMENT USING API
                        $entitlement = findEntitlementByID($token, $eID);

                        // STEP 21: CLEAN METADATA
                        unset($entitlement['metadata']['CreationDate']);
                        $entitlement['metadata']['Total_Codes'] = null;
                        $entitlement['metadata']['Total_Subscriptions'] = null;

                        // STEP 22: DUPLICATE ENTITLEMENT USING API
                        $duplicatedEntitlement = addEntitlement(
                            $token,
                            $duplicatedProductID,
                            $entitlement['entitlement_type_id'],
                            $entitlement['metadata']
                        );

                        // STEP 23: CHECK IF SUCCESSFUL DUPLICATE, ELSE LOG ERROR
                        if ($duplicatedEntitlement['success']) {

                            $duplicatedEntitlementID = $duplicatedEntitlement['data']['entitlement']['id'];
                            echo "$newISBN ($duplicatedProductID) -> $duplicatedEntitlementID \n";
                            addMessageToFile(
                                $successReportFile,
                                "$newISBN ($duplicatedProductID) -> $duplicatedEntitlementID"
                            );

                            // STEP 24: PUSH NEW E_ID TO ARRAY
                            $duplicatedEntitlementIDs[] = array(
                                "entitlement_id" => $duplicatedEntitlementID
                            );

                        } else {
                            addMessageToFile($errorFile, "$newISBN: Failed to duplicate entitlement");
                        }

                        $eIDMatchedCount++;
                        break;
                    }

                    if ($eIDMatchedCount === 0) {
                        addMessageToFile($errorFile, "$oldISBN: Failed to find batch for this ISBN");
                    }

                } else {
                    addMessageToFile($errorFile, "$oldISBN: Failed to find entitlements for this ISBN");
                }

            } else {
                addMessageToFile($errorFile, "$newISBN: Failed to duplicate product");
            }

        } else {

            // STEP 25: UPDATE METADATA
            $updatedProduct = editProductByID($token, $newProduct['data'][0]['id'], $productMetadataNew);

            // STEP 26: CHECK IF SUCCESSFUL EDIT, ELSE LOG
            if ($updatedProduct['success']) {

                $newProductMessage = $updatedProduct['message'];
                echo "$newISBN: $newProductMessage \n";
                addMessageToFile($successReportFile, "$newISBN: $newProductMessage");

            } else {
                addMessageToFile($errorFile, "$newISBN: Failed to update metadata for new ISBN");
            }

        }

    } else {
        addMessageToFile($errorFile, "$oldISBN: Failed to find product for this ISBN");
    }

}

// STEP 23: JSONIFY ARRAY AND STORE TO JSON FILE
addMessageToFile($entitlementIDsFile, json_encode($duplicatedEntitlementIDs));
