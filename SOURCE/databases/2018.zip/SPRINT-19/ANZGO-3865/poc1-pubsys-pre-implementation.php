<?php

// ANZGO-3865 Created by Shane Camus 9/21/2018
// POC1 FOR PUBSYS MIGRATION

define('ORIGIN_URL', 'cambridge.edu.au');
define('HEADER_CT_JSON', 'Content-Type: application/json');

function setConfig()
{
    $hostname = $_SERVER["HOSTNAME"];

    // 1 DEV, 2 UAT, 3 STAGING, 4 PROD, 5 LOCAL
    if ($hostname === 'ip-10-111-33-73') {
        define('SECRET_KEY', 'test1234');
        define('URL', 'https://hub-dev.cambridge.org/entitlement/api/v1/');
    } elseif ($hostname === 'ip-10-111-59-187') {
        define('SECRET_KEY', 'test1234');
        define('URL', 'https://hub-uat.cambridge.org/entitlement/api/v1/');
    } elseif ($hostname === 'ip-10-111-33-7') {
        define('SECRET_KEY', '83wue1eYyGX7Bs6pG8');
        define('URL', 'https://hub-stg.cambridge.org/entitlement/api/v1/');
    } elseif ($hostname === 'ip-10-111-60-73') {
        define('SECRET_KEY', 't12RSEKYBQSQzlbV5a');
        define('URL', 'https://peas.cambridge.org/entitlement/api/v1/');
    } else {
        define('SECRET_KEY', 'test1234');
        define('URL', 'localhost:3333/entitlement/api/v1/');
    }
}

function getAllISBNs()
{
    $file = fopen('isbns.csv', 'r');

    $isbn = array();
    while(!feof($file)) {
        $row = fgetcsv($file);
        $isbn[$row[0]] = $row[1];
    }

    fclose($file);
    array_pop($isbn);

    return $isbn;
}

function curlAPI($path, $method, $header, $payload)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, URL . $path);
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

    if ($header !== '') {
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(HEADER_CT_JSON, $header));
    } else {
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(HEADER_CT_JSON));
    }

    if ($payload !== '') {
        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($payload));
    }


    $output = json_decode(curl_exec($curl), true);
    curl_close($curl);

    return $output;
}

function generateCode()
{
    $params = array (
        'origin_url' => ORIGIN_URL,
        'secret_key' => SECRET_KEY
    );

    return curlAPI('auth/token/generate', 'POST', '', $params);
}

function findProductByISBN($token, $isbn)
{
    return curlAPI("products?metaFields=ISBN_13&keyword=$isbn" , 'GET', $token, '');
}


function findEntitlementByID($token, $id)
{
    return curlAPI("entitlements/$id", 'GET', $token, '');
}

function findEntitlementsByProductID($token, $pID)
{
    return curlAPI("entitlements?product_id=$pID", 'GET', $token, '');
}


function findBatchesByEntitlementIDAndName($token, $eID)
{
    if (curlAPI("batches?entitlement_id=$eID&name=web%20direct", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=web%20direct1", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=webdirect", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=edumar", 'GET', $token, '')['total'] ||
        curlAPI("batches?entitlement_id=$eID&name=website", 'GET', $token, '')['total']) {
        return $eID;
    } else {
        return false;
    }
}

function addMessageToFile($fileName, $message)
{
    $file = fopen($fileName, 'a+');
    $message .= "\r\n";
    fwrite($file, $message);
}

//--------------------------------------------  MAIN CODE --------------------------------------------

// STEP 0: DEFINE CONSTANT VARIABLES
setConfig();

// STEP 1: OPEN CSV FILE AND FETCH ISBNS
$isbns = getAllISBNs();

// STEP 2: GENERATE ACCESS TOKEN (NOTE EXPIRES WITHIN 2 HOURS)
$token = "Authorization: Bearer " . generateCode()['data']['token'];

// STEP 3: PREPARE ERROR, SUCCESS REPORT, AND JSON FILES
$errorFile = 'pubsys_error_file_pre_imp.txt';

// STEP 4: PREPARE ARRAY FOR ENTITLEMENT IDS
$duplicatedEntitlementIDs = array();

// STEP 5: LOOP THROUGH EACH ISBN AND FIND PRODUCT
foreach ($isbns as $oldISBN => $newISBN) {

    $product = findProductByISBN($token, $oldISBN);

    // STEP 6: CHECK IF PRODUCT EXISTS, ELSE LOG ERROR
    if ($product['total'] !== 0) {

        $productID = $product['data'][0]['id'];

        // STEP 7: FIND ENTITLEMENT BY NEW PRODUCT ID
        $entitlements = findEntitlementsByProductID($token, $productID);

        // STEP 8: CHECK IF ENTITLEMENT EXIST, ELSE LOG ERROR
        if ($entitlements['total'] !== 0) {
            $entitlementIDs = array_column($entitlements['data'], 'id');

            $eIDMatchedCount = 0;

            // STEP 9: LOOP THROUGH EACH ENTITLEMENT
            foreach ($entitlementIDs as $eID) {

                // STEP 10: CHECK FOR WEB DIRECT OR WEB DIRECT1 OR EDUMAR, ELSE LOG ERROR
                // ELSE LOG ERROR
                if (!findBatchesByEntitlementIDAndName($token, $eID)) {
                    continue;
                }

                echo "$oldISBN: Found batch from eID $eID \n";
                $eIDMatchedCount++;
                break;
            }

            if ($eIDMatchedCount === 0) {
                addMessageToFile($errorFile, "$oldISBN: Failed to find batch for this ISBN");
            }

        } else {
            addMessageToFile($errorFile, "$oldISBN: Failed to find entitlements for this ISBN");
        }

    } else {
        addMessageToFile($errorFile, "$oldISBN: Failed to find product for this ISBN");
    }

}
